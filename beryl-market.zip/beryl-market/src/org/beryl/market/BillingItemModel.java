package org.beryl.market;

public class BillingItemModel {

	public final String productId;
	public final String developerPayload;
	
	public BillingItemModel(String productId, String developerPayload) {
		this.productId = productId;
		this.developerPayload = developerPayload;
	}
	
	@Override
	public String toString() {
		return "BillingItemModel {productId= " + productId + ", developerPayload= " + developerPayload + "}";
	}
}
