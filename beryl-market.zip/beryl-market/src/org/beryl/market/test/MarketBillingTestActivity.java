package org.beryl.market.test;

import org.beryl.market.BillingCallback;
import org.beryl.market.BillingController;
import org.beryl.market.BillingItemModel;
import org.beryl.market.Consts.PurchaseState;
import org.beryl.market.Consts.ResponseCode;

import com.futonredemption.example.dungeons.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MarketBillingTestActivity extends Activity {
	
	private BillingController billingController;
	
	private BillingCallback mBillingCallback = new MyBillingCallback();
	
	class MyBillingCallback extends BillingCallback {

		public MyBillingCallback() {
			super(new BillingCallback.LoggingBillingCallback("BillingTest"));
		}
		
		@Override
		protected void onBillingSupported(boolean supported) {
			// TODO Auto-generated method stub
			
		}

		@Override
		protected void onPurchaseStateChanged(PurchaseState purchaseState,
				String itemId, int quantity, long purchaseTime,
				String developerPayload) {
			// TODO Auto-generated method stub
			
		}

		@Override
		protected void onRequestPurchaseResponse(BillingItemModel model,
				ResponseCode responseCode) {
			// TODO Auto-generated method stub
			
		}

		@Override
		protected void onRestoreTransactionsResponse(ResponseCode responseCode) {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	private String purchaseCode;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        purchaseCode = getString(R.string.android_test_purchased);
        
        billingController = new BillingController(this);
        
        Button buyButton = (Button)findViewById(R.id.buy_button);
        buyButton.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				billingController.beginPurchase(purchaseCode);
			}
		});
        Spinner selectCode = (Spinner) findViewById(R.id.purchase_code);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
        		R.array.purchase_codes,
        		android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectCode.setAdapter(adapter);
        selectCode.setOnItemSelectedListener(new OnItemSelectedListener() {

			public void onItemSelected(AdapterView<?> parent,
			        View view, int pos, long id) {
				purchaseCode = parent.getItemAtPosition(pos).toString();
			}

			public void onNothingSelected(AdapterView<?> arg0) {
				purchaseCode = getString(R.string.android_test_purchased);
			}
		});
    }
    
    @Override
    public void onStart() {
    	super.onStart();
    	billingController.start(mBillingCallback, this);
    }
    
    @Override
    public void onStop() {
    	super.onStop();
    	billingController.stop();
    }
    @Override
    protected void onDestroy() {
    	super.onDestroy();
    	billingController.destroy();
    }
}