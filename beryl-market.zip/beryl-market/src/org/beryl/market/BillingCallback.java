package org.beryl.market;

import org.beryl.market.Consts.PurchaseState;
import org.beryl.market.Consts.ResponseCode;

import android.util.Log;

public abstract class BillingCallback {

	public static class LoggingBillingCallback extends BillingCallback {
		
		private final String TAG;
		
		private void log(String message) {
			if (Consts.DEBUG) {
				Log.i(TAG, message);
            }
		}
		
		public LoggingBillingCallback(String tag) {
			super();
			this.TAG = tag;
		}
		
		public LoggingBillingCallback(BillingCallback child, String tag) {
			super(child);
			this.TAG = tag;
		}
		
		@Override
		protected void onBillingSupported(boolean supported) {
			log("onBillingSupported(supported= " + supported + ")");
			
		}

		@Override
		protected void onPurchaseStateChanged(PurchaseState purchaseState,
				String itemId, int quantity, long purchaseTime,
				String developerPayload) {
			log("onPurchaseStateChange(" + 
				"purchaseState= " + purchaseState.name() +
				",itemId= " + itemId +
				",quantity= " + quantity +
				",purchaseTime= " + purchaseTime +
				",developerPayload= " + developerPayload);
		}

		@Override
		protected void onRequestPurchaseResponse(BillingItemModel model,
				ResponseCode responseCode) {
			log("onRequestPurchaseResponse(" + 
					"model= " + model.toString() +
					",responseCode= " + responseCode.name());
		}

		@Override
		protected void onRestoreTransactionsResponse(ResponseCode responseCode) {
			log("onRestoreTransactionsResponse(" + 
					"responseCode= " + responseCode.name());
		}
	};
	
	private final BillingCallback child;
	
	public BillingCallback() {
		child = null;
	}
	
	public BillingCallback(BillingCallback child) {
		this.child = child;
	}
	
	public final void billingSupported(boolean supported) {
		onBillingSupported(supported);
		
		if(child != null)
			child.billingSupported(supported);
	}
	
	public final void purchaseStateChanged(PurchaseState purchaseState,
			String itemId, int quantity, long purchaseTime,
			String developerPayload) {
		onPurchaseStateChanged(purchaseState, itemId, quantity, purchaseTime, developerPayload);
		
		if(child != null)
			child.purchaseStateChanged(purchaseState, itemId, quantity, purchaseTime, developerPayload);
	}
	
	public final void requestPurchaseResponse(BillingItemModel model,
			ResponseCode responseCode) {
		onRequestPurchaseResponse(model, responseCode);
		
		if(child != null)
			child.requestPurchaseResponse(model, responseCode);
	}
	
	public void restoreTransactionsResponse(ResponseCode responseCode) {
		onRestoreTransactionsResponse(responseCode);
		
		if(child != null)
			child.restoreTransactionsResponse(responseCode);
	}
	
	protected abstract void onBillingSupported(boolean supported);
	protected abstract void onPurchaseStateChanged(PurchaseState purchaseState,
			String itemId, int quantity, long purchaseTime,
			String developerPayload);
	protected abstract void onRequestPurchaseResponse(BillingItemModel model,
			ResponseCode responseCode);
	protected abstract void onRestoreTransactionsResponse(ResponseCode responseCode);
}
