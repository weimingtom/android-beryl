package org.beryl.market;

import org.beryl.market.Consts.PurchaseState;
import org.beryl.market.Consts.ResponseCode;

public interface IBillingCallback {
	void onBillingSupported(boolean supported);
	void onPurchaseStateChanged(PurchaseState purchaseState, String itemId,
            int quantity, long purchaseTime, String developerPayload);
	void onRequestPurchaseResponse(BillingItemModel model,
            ResponseCode responseCode);
	void onRestoreTransactionsResponse(ResponseCode responseCode);
}
