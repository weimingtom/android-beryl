package org.beryl.market;

import org.beryl.market.Consts.PurchaseState;
import org.beryl.market.Consts.ResponseCode;

import android.app.Activity;
import android.os.Handler;

public class PurchaseObserverBillingCallback extends PurchaseObserver {

	private final BillingCallback callback;
	
	public PurchaseObserverBillingCallback(BillingCallback callback, Activity activity) {
		super(activity, new Handler());
		this.callback = callback;
	}

	@Override
	public void onBillingSupported(boolean supported) {
		callback.billingSupported(supported);
	}

	@Override
	public void onPurchaseStateChange(PurchaseState purchaseState,
			String itemId, int quantity, long purchaseTime,
			String developerPayload) {
		callback.purchaseStateChanged(purchaseState, itemId, quantity, purchaseTime, developerPayload);
	}

	@Override
	public void onRequestPurchaseResponse(BillingItemModel model,
			ResponseCode responseCode) {
		callback.requestPurchaseResponse(model, responseCode);
	}

	@Override
	public void onRestoreTransactionsResponse(ResponseCode responseCode) {
		callback.restoreTransactionsResponse(responseCode);
	}
}
