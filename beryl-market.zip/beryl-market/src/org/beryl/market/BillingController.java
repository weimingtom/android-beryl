package org.beryl.market;

import android.app.Activity;
import android.content.Context;

public class BillingController {

	private BillingService mBillingService = null;
	private PurchaseObserver observer;
	
	public BillingController(final Context context) {
		mBillingService = new BillingService();
		mBillingService.setContext(context);
	}
	
	public void start(BillingCallback callback, Activity activity) {
		this.observer = new PurchaseObserverBillingCallback(callback, activity);
		ResponseHandler.register(observer);
	}
	
	public void stop() {
		ResponseHandler.unregister(observer);
	}
	
	public void destroy() {
		mBillingService.unbind();
	}
	
	public void beginPurchase(String productId) {
		beginPurchase(productId, null);
	}
	
	public void restoreTransactions() {
		mBillingService.restoreTransactions();
	}
	
	public void beginPurchase(String productId, String developerPayload) {
		mBillingService.requestPurchase(productId, developerPayload);
	}
}
