package org.beryl.billing;

import android.os.Bundle;
import android.os.RemoteException;

interface IMarketBilling {

	boolean checkBillingSupported() throws RemoteException;

	Bundle requestPurchase(String productId, String developerPayload)
			throws RemoteException;

	long confirmNotifications(final String[] notificationIds)
			throws RemoteException;

	long getPurchaseInformation(long nonce, final String[] notificationIds)
			throws RemoteException;

	long restoreTransactions(long nonce) throws RemoteException;
}