package org.beryl.billing;

import org.beryl.billing.Constants.PurchaseState;
import org.beryl.billing.Constants.ResponseCode;
import org.beryl.billing.models.BillingItem;

public abstract class BillingCallback {

	private final BillingCallback child;
	
	public BillingCallback() {
		child = null;
	}
	
	public BillingCallback(BillingCallback child) {
		this.child = child;
	}
	
	final void billingSupported(boolean supported) {
		onBillingSupported(supported);
		
		if(child != null)
			child.billingSupported(supported);
	}
	
	final void purchaseStateChanged(PurchaseState purchaseState,
			String itemId, int quantity, long purchaseTime,
			String developerPayload) {
		onPurchaseStateChanged(purchaseState, itemId, quantity, purchaseTime, developerPayload);
		
		if(child != null)
			child.purchaseStateChanged(purchaseState, itemId, quantity, purchaseTime, developerPayload);
	}
	
	final void requestPurchaseResponse(BillingItem model,
			ResponseCode responseCode) {
		onRequestPurchaseResponse(model, responseCode);
		
		if(child != null)
			child.requestPurchaseResponse(model, responseCode);
	}
	
	final void restoreTransactionsResponse(ResponseCode responseCode) {
		onRestoreTransactionsResponse(responseCode);
		
		if(child != null)
			child.restoreTransactionsResponse(responseCode);
	}
	
	protected abstract void onBillingSupported(boolean supported);
	protected void onPurchaseStateChanged(PurchaseState purchaseState,
			String itemId, int quantity, long purchaseTime,
			String developerPayload) {
	}
	protected void onRequestPurchaseResponse(BillingItem model,
			ResponseCode responseCode) {
	}
	protected void onRestoreTransactionsResponse(ResponseCode responseCode) {
	}
}
