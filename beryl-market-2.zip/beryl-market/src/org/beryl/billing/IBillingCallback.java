package org.beryl.billing;

import org.beryl.app.RegisterableContract;
import org.beryl.billing.Constants.PurchaseState;
import org.beryl.billing.Constants.ResponseCode;
import org.beryl.billing.models.BillingItem;

public interface IBillingCallback extends RegisterableContract {
	void onBillingSupported(boolean supported);
	void onPurchaseStateChanged(PurchaseState purchaseState, String itemId,
            int quantity, long purchaseTime, String developerPayload);
	void onRequestPurchaseResponse(BillingItem model,
            ResponseCode responseCode);
	void onRestoreTransactionsResponse(ResponseCode responseCode);
}
