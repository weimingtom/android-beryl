package org.beryl.billing;

import org.beryl.billing.models.BillingItem;

import android.app.Activity;
import android.content.Context;

public class BillingController {

	private Context context;
	private PurchaseObserver observer;
	
	public BillingController(final Context context) {
		this.context = context;
	}
	
	public void start(final BillingCallback callback, final Activity activity) {
		this.observer = new PurchaseObserverBillingCallback(callback, activity);
		ResponseHandler.register(observer);
	}
	
	public void stop() {
		ResponseHandler.unregister(observer);
	}

	public void checkBillingSupported() {
		BillingService.checkBillingSupported(context);
	}
	
	public void restoreTransactions() {
		BillingService.restoreTransactions(context);
	}
	
	public void beginPurchase(String productId) {
		beginPurchase(productId, null);
	}
	
	public void beginPurchase(String productId, String developerPayload) {
		BillingService.requestPurchase(context, new BillingItem(productId, developerPayload));
	}
}
